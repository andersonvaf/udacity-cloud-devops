Course: Cloud DevOps Engineer
Project: Deploy Static Website on AWS

CloudFront domain name URL: https://d1vfd7oz9tk3mq.cloudfront.net/
Website-endpoint URL: http://my-006403268442-bucket.s3-website-us-east-1.amazonaws.com/
S3 object URL: https://my-006403268442-bucket.s3.amazonaws.com/index.html